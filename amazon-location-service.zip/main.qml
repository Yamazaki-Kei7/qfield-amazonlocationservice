import QtQuick
import QtQuick.Controls
import QtQuick.Controls.Material
import QtQuick.Layouts
import org.qgis
import org.qfield.core
import org.qfield.gui
import "Routes.js" as Routes
import "ButtonColors.js" as Colors

Item {
    id: plugin
    readonly property var window: iface.mainWindow()
    readonly property var canvas: iface.mapCanvas()
    readonly property var handler: iface.findItemByObjectName("pointHandler")
    readonly property var wgs84: QfCoordinateReferenceSystemUtils.wgs84Crs()
    readonly property var gnss: iface.findItemByObjectName("positionSource")
    readonly property var currentPosition: {
        if (!gnss || !gnss.active || !gnss.valid || !gnss.currentness) return null
        const fix = gnss.positionInformation
        if (!fix || !fix.isValid || !fix.longitudeValid || !fix.latitudeValid) return null
        const p = toWgs84(gnss.projectedPosition, canvas.mapSettings.destinationCrs)
        return Routes.validPosition(p) ? p : null
    }
    property var preview: null
    property bool needsOrigin: false
    property var stops: []
    property var travelMode: Routes.travelModes[0]
    property string routePreference: "ShortestRoute"
    readonly property string routeCriterion: Routes.routeCriterion(travelMode.id, routePreference)
    property string visitOrderOverride: ""
    readonly property string visitOrderCriterion: visitOrderOverride || routeCriterion
    // Optimizing the visit order always keeps the first stop; this keeps the last one too.
    property bool fixedEnd: false
    // The order replaced by the last optimization, for as long as it can be restored.
    property var undoStops: null
    property string optimizeNote: ""
    readonly property var pending: routeRequest.pending || optimizeRequest.pending
    readonly property bool optimizing: !!optimizeRequest.pending
    property bool picking: false
    property string message: ""
    readonly property string handlerName: "AmazonLocationRoutes"
    readonly property string serviceName: "Amazon Location Service"
    readonly property url serviceIcon: Qt.resolvedUrl("Arch_Amazon-Location-Service_32.svg")

    readonly property var colors: Colors.forTheme(QfTheme.darkTheme)
    readonly property int gutter: 16
    readonly property int stopMarkerSize: 24
    readonly property int touchHeight: 44
    readonly property real overlayBottomMargin: Math.max(window.sceneBottomMargin, canvas.bottomMargin) + gutter
    readonly property string region: regionField.text.trim()
    readonly property string apiKey: keyField.text.trim()
    readonly property int maxStops: Routes.stopLimit(travelMode.id)
    readonly property bool atLimit: stops.length >= maxStops
    readonly property bool canAddStop: !atLimit && !pending
    readonly property bool reorderable: stops.length > 1
    readonly property bool optimizable: Routes.supportsWaypoints(travelMode.id)
        && stops.length >= Routes.minOptimizeStops(false)
    readonly property bool canOptimize: optimizable && stops.length >= Routes.minOptimizeStops(fixedEnd)
        && !connectionHint && !pending
    readonly property string statusText: message || searchHint
    readonly property string searchHint: {
        if (stops.length > maxStops) return travelMode.label + " supports up to " + maxStops + " stops. Remove stops or change the travel mode."
        if (stops.length === 0) return "Add an origin and destination in visit order."
        if (needsOrigin) return "Destination selected. Add an origin."
        if (stops.length === 1) return "Add one more stop as the destination."
        return connectionHint
    }
    readonly property string connectionHint: {
        if (!regionField.validRegion) return "Enter an AWS Region (e.g. ap-northeast-1)."
        if (!apiKey) return "Enter an Amazon Location API key."
        return ""
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(serviceButton)
        iface.addItemToPluginsToolbar(placeButton)
        iface.addItemToPluginsToolbar(routeButton)
        handler.registerHandler(handlerName, pickPoint, QfMapCanvasPointHandler.Priority.High)
    }
    Component.onDestruction: {
        if (handler) handler.deregisterHandler(handlerName)
    }

    function pickPoint(screenPoint, device, interaction) {
        if (!picking || interaction !== "clicked") return false
        if (pending) return true
        const mapPoint = canvas.mapSettings.screenToCoordinate(screenPoint)
        addStop(mapPoint, canvas.mapSettings.destinationCrs, "Map point")
        return true
    }

    function toWgs84(point, crs) {
        const p = QfGeometryUtils.reprojectPointToWgs84(point, crs)
        return [p.x, p.y]
    }

    function toMapCrs(position) {
        const p = QfGeometryUtils.point(position[0], position[1])
        return QfGeometryUtils.reprojectPoint(p, wgs84, canvas.mapSettings.destinationCrs)
    }

    function addStop(point, crs, label, featureKey = "") {
        addPosition(toWgs84(point, crs), label, false, featureKey)
    }

    function addPosition(position, label, asDestination = false, featureKey = "") {
        if (pending) return
        if (atLimit) {
            window.displayToast(travelMode.label + " supports up to " + maxStops + " stops.")
            return
        }
        // QML list delegates can supply a QVariantList instead of a JavaScript array.
        const coordinates = position && [position[0], position[1]]
        if (!Routes.validPosition(coordinates)) {
            window.displayToast("Could not get coordinates for this stop.")
            return
        }
        const stop = { position: coordinates, label: label, featureKey: featureKey }
        if (asDestination && (!stops.length || needsOrigin)) {
            needsOrigin = true
            stops = [stop]
        } else if (needsOrigin) {
            needsOrigin = false
            stops = [stop].concat(stops)
        } else {
            stops = stops.concat([stop])
        }
        window.displayToast("Added " + label + " to the route.")
    }

    function mapCenter() {
        return toWgs84(canvas.mapSettings.center, canvas.mapSettings.destinationCrs)
    }

    function showPlace(place) {
        preview = place
        canvas.mapSettings.setCenter(toMapCrs(place.position), true)
    }

    function openPlaces(forRoute) {
        picking = false
        preview = null
        places.forRoute = forRoute
        placeSearch.reset()
        places.open()
    }

    function usePreview() {
        if (!preview || !canAddStop) return
        const place = preview
        preview = null
        if (!stops.length && currentPosition) addPosition(currentPosition, "Current location")
        addPosition(place.position, place.label, true)
        panel.open()
    }

    function moveStop(from, to) {
        if (pending || from < 0 || from >= stops.length || to < 0 || to >= stops.length || from === to) return
        const reordered = stops.slice()
        const stop = reordered.splice(from, 1)[0]
        reordered.splice(to, 0, stop)
        stops = reordered
    }

    function stopRole(index) {
        if (needsOrigin) return "Destination"
        if (index === 0) return "Origin"
        return index === stops.length - 1 ? "Destination" : "Stop"
    }

    onStopsChanged: {
        if (!stops.length) needsOrigin = false
        if (stopRows) stopRows.dragIndex = -1
        undoStops = null
        clearRoute()
    }
    onTravelModeChanged: clearRoute()
    onRoutePreferenceChanged: clearRoute()
    onVisitOrderOverrideChanged: {
        optimizeNote = ""
        message = ""
    }
    onFixedEndChanged: optimizeNote = ""

    function clearRoute() {
        routeRequest.cancel()
        optimizeRequest.cancel()
        route.geometryWrapper.clear()
        message = ""
        optimizeNote = ""
    }

    onMessageChanged: {
        if (picking && message) window.displayToast(message)
    }

    function fitRouteOnMap(geometry) {
        const settings = canvas.mapSettings
        const projected = QfGeometryUtils.reprojectGeometry(geometry, wgs84, settings.destinationCrs)
        const bounds = QfGeometryUtils.boundingBox(projected)
        // A selected stop can be outside the route when the service snaps it to a road.
        for (const stop of stops) {
            const p = toMapCrs(stop.position)
            bounds.xMinimum = Math.min(bounds.xMinimum, p.x)
            bounds.xMaximum = Math.max(bounds.xMaximum, p.x)
            bounds.yMinimum = Math.min(bounds.yMinimum, p.y)
            bounds.yMaximum = Math.max(bounds.yMaximum, p.y)
        }

        // Measure the bounds along the screen axes, including when the map is rotated.
        const angle = settings.rotation * Math.PI / 180
        const cos = Math.abs(Math.cos(angle))
        const sin = Math.abs(Math.sin(angle))
        const inset = stopMarkerSize / 2 + gutter
        const unitsPerPoint = Math.max(
            (bounds.width * cos + bounds.height * sin) / Math.max(1, canvas.width - 2 * inset),
            (bounds.width * sin + bounds.height * cos) / Math.max(1, canvas.height - 2 * inset))
        const center = bounds.center
        if (!unitsPerPoint) {
            settings.setCenter(QfGeometryUtils.point(center.x, center.y))
            return
        }
        const halfWidth = unitsPerPoint * canvas.width / 2
        const halfHeight = unitsPerPoint * canvas.height / 2
        iface.setMapExtent(QfGeometryUtils.createRectangleFromPoints(
            QfGeometryUtils.point(center.x - halfWidth, center.y - halfHeight),
            QfGeometryUtils.point(center.x + halfWidth, center.y + halfHeight)))
    }

    function search() {
        if (pending || searchHint) return
        const body = Routes.requestBody(stops, travelMode.id, routePreference)
        message = ""
        routeRequest.post("routes", "routes", body, text => {
            try {
                const data = JSON.parse(text)
                const geometry = QfGeometryUtils.createGeometryFromWkt(Routes.routeWkt(data, body))
                route.geometryWrapper.crs = wgs84
                route.geometryWrapper.qgsGeometry = geometry
                fitRouteOnMap(geometry)
                picking = false
                panel.close()
                window.displayToast(travelMode.label + " route with " + stops.length + " stops displayed.")
            } catch (error) {
                message = error.message
            }
        })
    }

    function optimize() {
        if (!canOptimize) return
        const before = stops
        const fixed = fixedEnd
        message = ""
        const body = Routes.optimizeBody(before, travelMode.id, fixed, visitOrderCriterion)
        optimizeRequest.post("routes", "optimize-waypoints", body, text => {
            try {
                const result = Routes.optimizedStops(JSON.parse(text), before, fixed)
                if (result.changed) {
                    // Changing the stops clears the undo order and the note, so both are set afterwards.
                    stops = result.stops
                    undoStops = before
                }
                optimizeNote = (result.changed ? "Visit order optimized" : "Visit order is already optimal") + result.summary + "."
            } catch (error) {
                message = error.message
            }
        })
    }

    function undoOptimize() {
        if (pending || !undoStops) return
        stops = undoStops
    }

    LocationRequest {
        id: routeRequest
        region: plugin.region
        apiKey: plugin.apiKey
        onFailed: reason => plugin.message = reason
        onRejected: (status, responseText) => plugin.message = Routes.rejection("Could not find a route", status, responseText)
    }

    LocationRequest {
        id: optimizeRequest
        region: plugin.region
        apiKey: plugin.apiKey
        onFailed: reason => plugin.message = reason
        onRejected: status => plugin.message = Routes.optimizeRejection(status, plugin.stops)
    }

    Connections {
        target: iface
        function onLoadProjectTriggered() {
            plugin.picking = false
            serviceButton.checked = false
            settingsPopup.close()
            places.close()
            plugin.preview = null
            features.close()
            panel.close()
            matches.clear()
            plugin.stops = []
        }
    }

    QfToolButton {
        id: serviceButton
        readonly property int iconSize: Math.round(width * 0.7)
        round: true
        checkable: true
        bgcolor: Colors.ink
        padding: 0
        iconSource: plugin.serviceIcon
        iconColor: "transparent"
        icon.width: serviceButton.iconSize
        icon.height: serviceButton.iconSize
        bottomRightIndicatorText: plugin.picking ? String(plugin.stops.length) : (checked ? "▴" : "▾")
        bottomRightIndicatorBgColor: Colors.orange
        bottomRightIndicatorFgColor: Colors.ink
        statusBadge.bottomMargin: 0
        statusBadge.rightMargin: 0
        Accessible.name: plugin.serviceName
        Accessible.description: checked ? "Hide search buttons" : "Show search buttons"
        ToolTip.text: plugin.serviceName
        ToolTip.visible: hovered && !checked
        ToolTip.delay: 600
    }

    component SearchToolButton: QfToolButton {
        round: true
        visible: serviceButton.checked
        display: AbstractButton.IconOnly
        bgcolor: QfTheme.toolButtonBackgroundColor
        opacity: enabled ? 1 : 0.4
        Accessible.name: text
        ToolTip.text: text
        ToolTip.visible: hovered
        ToolTip.delay: serviceButton.ToolTip.delay
        onClicked: serviceButton.checked = false
    }

    SearchToolButton {
        id: placeButton
        text: "Place Search"
        iconSource: Qt.resolvedUrl("poi-search.svg")
        enabled: !plugin.pending
        onClicked: plugin.openPlaces(false)
    }

    SearchToolButton {
        id: routeButton
        text: "Route Search"
        iconSource: Qt.resolvedUrl("icon.svg")
        onClicked: {
            plugin.picking = false
            plugin.preview = null
            panel.open()
        }
    }

    QfGeometryRenderer {
        id: route
        parent: plugin.canvas
        anchors.fill: parent
        mapSettings: plugin.canvas.mapSettings
        color: "#0079bd"
        lineWidth: 5
    }

    Item {
        parent: plugin.canvas
        anchors.fill: parent
        z: route.z + 1
        Repeater {
            model: plugin.preview ? plugin.stops.concat([plugin.preview]) : plugin.stops
            delegate: Rectangle {
                required property var modelData
                required property int index
                CoordinateTransformer {
                    id: transformPoint
                    sourceCrs: plugin.wgs84
                    sourcePosition: QfGeometryUtils.point(modelData.position[0], modelData.position[1])
                    destinationCrs: plugin.canvas.mapSettings.destinationCrs
                    transformContext: qgisProject.transformContext
                }
                QfMapToScreen {
                    id: marker
                    mapSettings: plugin.canvas.mapSettings
                    mapPoint: transformPoint.projectedPosition
                }
                readonly property bool isPlace: index === plugin.stops.length
                width: isPlace ? 30 : plugin.stopMarkerSize
                height: width
                radius: width / 2
                x: marker.screenPoint.x - width / 2
                y: marker.screenPoint.y - height / 2
                color: isPlace ? Colors.blue : Colors.ink
                border.color: "white"
                Text { anchors.centerIn: parent; text: isPlace ? "●" : index + 1; color: "white" }
            }
        }
    }

    Pane {
        parent: plugin.canvas.parent
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: plugin.overlayBottomMargin
        width: Math.min(410, parent.width - 2 * plugin.gutter)
        visible: !!plugin.preview
        padding: 12
        background: Rectangle { radius: 8; color: QfTheme.groupBoxSurfaceColor; border.color: QfTheme.controlBorderColor }
        contentItem: ColumnLayout {
            RowLayout {
                Layout.fillWidth: true
                Label {
                    Layout.fillWidth: true
                    text: plugin.preview ? plugin.preview.label : ""
                    textFormat: Text.PlainText
                    font: QfTheme.strongResultFont
                    wrapMode: Text.Wrap
                }
                LocationButton {
                    text: "×"
                    horizontalPadding: 0
                    leftPadding: horizontalPadding
                    rightPadding: horizontalPadding
                    Accessible.name: "Close place details"
                    Layout.minimumWidth: plugin.touchHeight
                    Layout.minimumHeight: plugin.touchHeight
                    onClicked: plugin.preview = null
                }
            }
            Label {
                Layout.fillWidth: true
                text: plugin.preview ? plugin.preview.address : ""
                visible: !!text
                textFormat: Text.PlainText
                wrapMode: Text.Wrap
                color: QfTheme.secondaryTextColor
            }
            ColumnLayout {
                Layout.fillWidth: true
                LocationButton {
                    text: plugin.atLimit ? "Stop limit reached" :
                        !plugin.stops.length && plugin.currentPosition ? "Route from current location" :
                        plugin.stops.length && !plugin.needsOrigin ? "Add as destination" : "Route to here"
                    Layout.fillWidth: true
                    leftPadding: 8
                    rightPadding: 8
                    enabled: plugin.canAddStop
                    Layout.minimumHeight: plugin.touchHeight
                    primary: true
                    onClicked: plugin.usePreview()
                }
                LocationButton {
                    text: "Back to results"
                    Layout.fillWidth: true
                    onClicked: {
                        plugin.preview = null
                        places.open()
                    }
                }
            }
        }
    }

    QfMultiFeatureListModel { id: matches }

    LocationButton {
        parent: plugin.canvas.parent
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: plugin.overlayBottomMargin
        height: Math.max(implicitHeight, plugin.touchHeight)
        visible: plugin.picking && plugin.stops.length >= 2
        enabled: !plugin.pending
        text: plugin.pending ? "Finding route…" : plugin.searchHint ? "Enter settings" : "Find route"
        Accessible.description: plugin.statusText
        primary: true
        onClicked: {
            if (plugin.searchHint) {
                plugin.picking = false
                panel.open()
                settingsPopup.open()
            } else {
                plugin.search()
            }
        }
    }

    component RoutePopup: Popup {
        parent: plugin.window.contentItem
        anchors.centerIn: parent
        width: Math.min(440, parent.width - 16)
        height: Math.min(640, parent.height - 16)
        padding: 0
        modal: true
        focus: true
        Material.accent: plugin.colors.selected.background
    }

    component PanelHeader: Rectangle {
        id: header
        property string title
        property string dismissText: "Close"
        property bool primaryDismiss: false
        signal dismissed()
        Layout.fillWidth: true
        implicitHeight: headerRow.implicitHeight + 16
        color: Colors.ink
        RowLayout {
            id: headerRow
            anchors.fill: parent
            anchors.leftMargin: plugin.gutter
            anchors.rightMargin: 8
            spacing: 10
            Image {
                source: plugin.serviceIcon
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
            }
            ColumnLayout {
                Layout.fillWidth: true
                Layout.minimumWidth: 0
                spacing: 1
                Label { Layout.fillWidth: true; text: plugin.serviceName; color: "white"; font: QfTheme.tipFont; wrapMode: Text.Wrap }
                Label { Layout.fillWidth: true; text: header.title; color: "white"; font: QfTheme.strongTitleFont; wrapMode: Text.Wrap }
            }
            LocationButton {
                text: header.dismissText
                primary: header.primaryDismiss
                Layout.minimumHeight: plugin.touchHeight
                onClicked: header.dismissed()
            }
        }
    }

    component SectionTitle: Label {
        Layout.fillWidth: true
        Layout.topMargin: 12
        font: QfTheme.strongResultFont
    }

    component CircleBadge: Label {
        id: badge
        property color fill
        property int minimumSize: 26
        font: QfTheme.strongResultFont
        horizontalAlignment: Text.AlignHCenter
        verticalAlignment: Text.AlignVCenter
        Layout.preferredWidth: Math.max(minimumSize, implicitWidth + 8, implicitHeight)
        Layout.preferredHeight: Layout.preferredWidth
        background: Rectangle { radius: height / 2; color: badge.fill }
    }

    component MoveButton: LocationButton {
        required property int stopIndex
        required property int step
        readonly property int target: stopIndex + step
        horizontalPadding: 0
        leftPadding: horizontalPadding
        rightPadding: horizontalPadding
        text: step < 0 ? "↑" : "↓"
        visible: plugin.reorderable
        enabled: !plugin.pending && target >= 0 && target < plugin.stops.length
        Accessible.name: "Move stop " + (stopIndex + 1) + (step < 0 ? " up" : " down")
        onClicked: plugin.moveStop(stopIndex, target)
        Layout.preferredWidth: plugin.touchHeight
        Layout.minimumHeight: plugin.touchHeight
        ToolTip.visible: hovered || pressed
        ToolTip.text: Accessible.name
        ToolTip.delay: 600
    }

    component StopCard: Pane {
        id: card
        required property int index
        readonly property var stop: plugin.stops[index]
        Layout.fillWidth: true
        Layout.minimumWidth: 0
        Layout.topMargin: 4
        readonly property bool held: stopRows.dragIndex === index
        z: held ? 1 : 0
        transform: Translate { y: stopRows.displacement(card.index) }
        padding: 10
        background: Rectangle {
            radius: 8
            color: QfTheme.groupBoxSurfaceColor
            border.color: card.held ? plugin.colors.selected.background : QfTheme.controlBorderColor
            border.width: card.held ? 2 : 1
        }
        contentItem: RowLayout {
            spacing: 6
            MouseArea {
                Layout.preferredWidth: plugin.touchHeight
                Layout.preferredHeight: Math.max(plugin.touchHeight, gripLabels.implicitHeight)
                enabled: plugin.reorderable && !plugin.pending
                preventStealing: true
                cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                onPressed: mouse => {
                    form.contentItem.cancelFlick()
                    stopRows.pressY = mapToItem(form, mouse.x, mouse.y).y
                    stopRows.pointerY = stopRows.pressY
                    stopRows.startScroll = form.contentItem.contentY
                }
                onPositionChanged: mouse => {
                    if (!pressed) return
                    stopRows.pointerY = mapToItem(form, mouse.x, mouse.y).y
                    if (!card.held && Math.abs(stopRows.pointerY - stopRows.pressY) >= Qt.styleHints.startDragDistance)
                        stopRows.dragIndex = card.index
                }
                onReleased: mouse => {
                    if (!card.held) return
                    stopRows.pointerY = mapToItem(form, mouse.x, mouse.y).y
                    const target = stopRows.targetIndex
                    stopRows.dragIndex = -1
                    plugin.moveStop(card.index, target)
                }
                onCanceled: if (card.held) stopRows.dragIndex = -1
                ColumnLayout {
                    id: gripLabels
                    anchors.centerIn: parent
                    spacing: 2
                    CircleBadge {
                        text: card.index + 1
                        color: "white"
                        fill: Colors.ink
                        Layout.alignment: Qt.AlignHCenter
                    }
                    Label {
                        visible: plugin.reorderable
                        Layout.alignment: Qt.AlignHCenter
                        text: "⠿"
                        color: QfTheme.secondaryTextColor
                        Accessible.ignored: true
                    }
                }
            }
            ColumnLayout {
                Layout.fillWidth: true
                Layout.minimumWidth: 0
                spacing: 2
                Label {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    text: plugin.stopRole(card.index)
                    wrapMode: Text.Wrap
                    color: QfTheme.secondaryTextColor
                    font: QfTheme.tipFont
                }
                Label {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    text: card.stop ? card.stop.label : ""
                    textFormat: Text.PlainText
                    wrapMode: Text.Wrap
                    font: QfTheme.strongResultFont
                }
                Label {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    text: card.stop ? card.stop.position[1].toFixed(5) + ", " + card.stop.position[0].toFixed(5) : ""
                    color: QfTheme.secondaryTextColor
                    wrapMode: Text.Wrap
                    font: QfTheme.tipFont
                }
            }
            MoveButton { stopIndex: card.index; step: -1 }
            MoveButton { stopIndex: card.index; step: 1 }
        }
    }

    RoutePopup {
        id: panel
        onAboutToHide: {
            stopRows.dragIndex = -1
            routeRequest.cancel()
            optimizeRequest.cancel()
        }
        ColumnLayout {
            anchors.fill: parent
            spacing: 0
            PanelHeader { title: "Route Search"; onDismissed: panel.close() }
            ScrollView {
                id: form
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 0
                clip: true
                contentWidth: availableWidth
                leftPadding: plugin.gutter
                rightPadding: plugin.gutter
                ColumnLayout {
                    width: form.availableWidth
                    spacing: 4
                    RowLayout {
                        Layout.fillWidth: true
                        SectionTitle { text: "Travel mode"; Layout.topMargin: 0 }
                        LocationButton { text: "Settings"; enabled: !plugin.pending; onClicked: settingsPopup.open() }
                    }
                    GridLayout {
                        id: travelModeGrid
                        readonly property int iconSize: 18
                        Layout.fillWidth: true
                        columns: width < 250 ? 1 : width < 390 ? 2 : 3
                        columnSpacing: 4
                        rowSpacing: 0
                        enabled: !plugin.pending
                        Repeater {
                            model: Routes.travelModes
                            delegate: LocationButton {
                                required property var modelData
                                Layout.fillWidth: true
                                Layout.preferredWidth: 1
                                Layout.minimumHeight: plugin.touchHeight
                                Layout.preferredHeight: implicitContentHeight + verticalPadding * 2
                                horizontalPadding: 4
                                leftPadding: horizontalPadding
                                rightPadding: horizontalPadding
                                verticalPadding: 2
                                spacing: 4
                                text: modelData.label
                                icon.source: Qt.resolvedUrl("icons/" + modelData.id + ".svg")
                                icon.width: travelModeGrid.iconSize
                                icon.height: travelModeGrid.iconSize
                                icon.color: Material.foreground
                                checkable: true
                                autoExclusive: true
                                checked: plugin.travelMode.id === modelData.id
                                font.bold: checked
                                Accessible.role: Accessible.RadioButton
                                onClicked: if (plugin.travelMode.id !== modelData.id) plugin.travelMode = modelData
                            }
                        }
                    }
                    GridLayout {
                        id: routeChoices
                        Layout.fillWidth: true
                        visible: Routes.allowsShortestRoute(plugin.travelMode.id)
                        enabled: !plugin.pending
                        columns: 2
                        rowSpacing: 0
                        Label {
                            Layout.columnSpan: routeChoices.columns
                            text: "Route preference"
                        }
                        Repeater {
                            model: Routes.routeCriteria
                            RadioButton {
                                required property string modelData
                                Layout.minimumHeight: plugin.touchHeight
                                text: Routes.criterionLabel(modelData)
                                Accessible.name: "Route preference: " + text
                                checked: plugin.routeCriterion === modelData
                                onClicked: plugin.routePreference = modelData
                            }
                        }
                    }
                    Label {
                        visible: !routeChoices.visible
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        color: QfTheme.secondaryTextColor
                        text: plugin.routeCriterion ? plugin.travelMode.label + " routes prioritize travel time."
                            : "Choose an origin and destination. Departure is now."
                    }
                    SectionTitle { text: plugin.needsOrigin ? "Choose origin" : "Add stops" }
                    LocationButton {
                        Layout.fillWidth: true
                        Layout.minimumHeight: plugin.touchHeight
                        enabled: plugin.canAddStop
                        text: plugin.needsOrigin ? "Search for origin" : plugin.stops.length > 1 ? "Search for next destination" : "Search for destination"
                        onClicked: plugin.openPlaces(true)
                    }
                    LocationButton {
                        Layout.fillWidth: true
                        Layout.minimumHeight: plugin.touchHeight
                        enabled: !!plugin.currentPosition && plugin.canAddStop
                        text: plugin.needsOrigin || !plugin.stops.length ? "Use current location as origin" : "Add current location"
                        leftPadding: 8
                        rightPadding: 8
                        onClicked: plugin.addPosition(plugin.currentPosition, "Current location")
                    }
                    Label {
                        Layout.fillWidth: true
                        visible: !plugin.currentPosition
                        wrapMode: Text.Wrap
                        text: plugin.gnss && plugin.gnss.active ? "Waiting for a location fix." : "Turn on positioning in QField to use your current location."
                        color: QfTheme.secondaryTextColor
                        font: QfTheme.tipFont
                    }
                    LocationButton {
                        text: "Add stops from map"
                        Layout.fillWidth: true
                        Layout.minimumHeight: plugin.touchHeight
                        enabled: plugin.canAddStop
                        onClicked: {
                            panel.close()
                            plugin.picking = true
                            plugin.window.displayToast("Tap the map in visit order. Find a route after adding at least two stops.")
                        }
                    }
                    LocationButton {
                        id: layerToggle
                        checkable: true
                        Layout.fillWidth: true
                        text: checked ? "Add from layer ▴" : "Add from layer ▾"
                    }
                    Label { id: layerLabel; text: "Layer for feature selection"; visible: layerToggle.checked }
                    ComboBox {
                        id: layers
                        visible: layerToggle.checked
                        Layout.fillWidth: true
                        Accessible.name: layerLabel.text
                        model: QfMapLayerModel { project: qgisProject; filters: Qgis.LayerFilters.HasGeometry }
                        textRole: "Name"
                        valueRole: "LayerPointer"
                        displayText: count ? currentText : "No suitable layers"
                    }
                    LocationButton {
                        visible: layerToggle.checked
                        text: "Select layer features"
                        Layout.fillWidth: true
                        Layout.minimumHeight: plugin.touchHeight
                        enabled: !!layers.currentValue && !plugin.pending
                        onClicked: features.open()
                    }
                    SectionTitle {
                        Layout.topMargin: 8
                        text: "Visit order (" + plugin.stops.length + " / " + plugin.maxStops + ")"
                    }
                    ColumnLayout {
                        visible: plugin.optimizable
                        Layout.fillWidth: true
                        spacing: 4
                        Label {
                            id: visitOrderLabel
                            text: "Visit order preference"
                        }
                        ComboBox {
                            id: orderChoice
                            Layout.fillWidth: true
                            Layout.minimumHeight: plugin.touchHeight
                            enabled: !plugin.pending
                            Accessible.name: visitOrderLabel.text
                            readonly property var criteria: [""].concat(Routes.routeCriteria)
                            model: criteria.map(value => value ? Routes.criterionLabel(value)
                                : "Same as route (" + Routes.criterionLabel(plugin.routeCriterion) + ")")
                            currentIndex: criteria.indexOf(plugin.visitOrderOverride)
                            onActivated: index => plugin.visitOrderOverride = criteria[index]
                        }
                        RowLayout {
                            Layout.fillWidth: true
                            Label {
                                id: fixedEndLabel
                                Layout.fillWidth: true
                                text: "Keep last stop as destination"
                                wrapMode: Text.Wrap
                            }
                            Switch {
                                Layout.minimumHeight: plugin.touchHeight
                                enabled: !plugin.pending
                                checked: plugin.fixedEnd
                                Accessible.name: fixedEndLabel.text
                                onToggled: plugin.fixedEnd = checked
                            }
                        }
                        Label {
                            Layout.fillWidth: true
                            wrapMode: Text.Wrap
                            text: plugin.fixedEnd && plugin.stops.length < Routes.minOptimizeStops(true)
                                ? "At least " + Routes.minOptimizeStops(true) + " stops are needed to keep the destination fixed."
                                : plugin.fixedEnd ? "Keep the origin and destination fixed; reorder the stops in between."
                                : "Keep the origin fixed; reorder the remaining stops."
                            color: QfTheme.secondaryTextColor
                            font: QfTheme.tipFont
                        }
                        LocationButton {
                            Layout.fillWidth: true
                            Layout.minimumHeight: plugin.touchHeight
                            enabled: plugin.canOptimize
                            text: plugin.optimizing ? "Optimizing…" : "Optimize order"
                            onClicked: plugin.optimize()
                        }
                        Label {
                            Layout.fillWidth: true
                            visible: text.length > 0
                            wrapMode: Text.Wrap
                            text: plugin.optimizeNote
                        }
                        LocationButton {
                            visible: !!plugin.undoStops
                            enabled: !plugin.pending
                            text: "Restore original order"
                            Layout.minimumHeight: plugin.touchHeight
                            onClicked: plugin.undoOptimize()
                        }
                    }
                    Label {
                        visible: plugin.reorderable
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        text: "Drag the numbers up or down to reorder."
                        color: QfTheme.secondaryTextColor
                    }
                    Repeater {
                        id: stopRows
                        property int dragIndex: -1
                        property real pressY
                        property real pointerY
                        property real startScroll
                        readonly property real offset: dragIndex < 0 ? 0 :
                            pointerY - pressY + form.contentItem.contentY - startScroll
                        readonly property int targetIndex: {
                            if (dragIndex < 0 || dragIndex >= count) return -1
                            const held = itemAt(dragIndex)
                            const center = held.y + held.height / 2 + offset
                            let target = dragIndex
                            while (target < count - 1 && center > midpoint(target + 1)) ++target
                            while (target > 0 && center < midpoint(target - 1)) --target
                            return target
                        }
                        function midpoint(index) {
                            const item = itemAt(index)
                            return item.y + item.height / 2
                        }
                        function displacement(index) {
                            if (dragIndex < 0 || dragIndex >= count) return 0
                            const held = itemAt(dragIndex)
                            if (index === dragIndex)
                                return Math.max(itemAt(0).y - held.y,
                                    Math.min(offset, itemAt(count - 1).y + itemAt(count - 1).height - held.y - held.height))
                            const step = held.height + held.Layout.topMargin + held.parent.spacing
                            if (index > dragIndex && index <= targetIndex) return -step
                            if (index < dragIndex && index >= targetIndex) return step
                            return 0
                        }
                        model: plugin.stops.length
                        delegate: StopCard {}
                    }
                    RowLayout {
                        visible: plugin.stops.length > 0
                        enabled: !plugin.pending
                        LocationButton { text: "Remove last"; destructive: true; onClicked: plugin.stops = plugin.stops.slice(0, -1) }
                        LocationButton { text: "Clear all"; destructive: true; onClicked: plugin.stops = [] }
                    }
                }
            }
            Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: QfTheme.controlBorderColor }
            ColumnLayout {
                Layout.fillWidth: true
                Layout.margins: plugin.gutter
                spacing: 6
                ProgressBar {
                    Layout.fillWidth: true
                    visible: !!plugin.pending
                    indeterminate: visible
                    Accessible.name: plugin.optimizing ? "Optimizing visit order" : "Finding route"
                }
                Label {
                    Layout.fillWidth: true
                    visible: text.length > 0
                    wrapMode: Text.Wrap
                    text: plugin.statusText
                    textFormat: Text.PlainText
                    color: plugin.message ? plugin.colors.danger.foreground : QfTheme.mainTextColor
                }
                LocationButton {
                    Layout.fillWidth: true
                    Layout.minimumHeight: 48
                    enabled: !plugin.pending && !plugin.searchHint
                    Accessible.description: plugin.statusText
                    text: routeRequest.pending ? "Finding route…"
                          : "Find route" + (width < 250 ? "\n" : " · ") + plugin.travelMode.label
                            + (plugin.routeCriterion ? " · " + Routes.criterionLabel(plugin.routeCriterion) : "")
                    topInset: 0
                    bottomInset: 0
                    leftPadding: 8
                    rightPadding: 8
                    font: QfTheme.strongTitleFont
                    primary: true
                    onClicked: plugin.search()
                }
            }
        }
    }

    Timer {
        interval: 24
        repeat: true
        running: stopRows.dragIndex >= 0 && (stopRows.pointerY < plugin.touchHeight ||
            stopRows.pointerY > form.height - plugin.touchHeight)
        onTriggered: {
            const view = form.contentItem
            const first = stopRows.itemAt(0)
            const last = stopRows.itemAt(stopRows.count - 1)
            const edge = plugin.touchHeight
            const up = stopRows.pointerY < edge
            if (up && first.parent.mapToItem(form, 0, first.y).y >= 0) return
            if (!up && last.parent.mapToItem(form, 0, last.y + last.height).y <= form.height) return
            const step = edge / 5
            view.contentY = Math.max(view.originY, Math.min(view.contentY + (up ? -step : step),
                view.originY + view.contentHeight - view.height))
        }
    }

    RoutePopup {
        id: places
        property bool forRoute: false
        onAboutToHide: placeSearch.cancel()
        ColumnLayout {
            anchors.fill: parent
            spacing: 0
            PanelHeader {
                title: places.forRoute ? (plugin.needsOrigin ? "Find Origin" : "Find Destination") : "Place Search"
                dismissText: places.forRoute ? "Back" : "Close"
                onDismissed: places.close()
            }
            PlaceSearch {
                id: placeSearch
                Layout.fillWidth: true
                Layout.fillHeight: true
                region: plugin.region
                apiKey: plugin.apiKey
                connectionHint: plugin.connectionHint
                searchCenter: plugin.mapCenter
                gutter: plugin.gutter
                touchHeight: plugin.touchHeight
                selectionHint: places.forRoute ? "Select a place to add to the route." : "Select a place to show it on the map."
                onSettingsRequested: settingsPopup.open()
                onChosen: place => {
                    places.close()
                    if (places.forRoute) plugin.addPosition(place.position, place.label, !plugin.needsOrigin)
                    else plugin.showPlace(place)
                }
            }
        }
    }

    RoutePopup {
        id: settingsPopup
        height: Math.min(340, parent.height - 16)
        ColumnLayout {
            anchors.fill: parent
            spacing: 0
            PanelHeader { title: "Settings"; dismissText: "Done"; primaryDismiss: true; onDismissed: settingsPopup.close() }
            ScrollView {
                id: settingsForm
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                padding: plugin.gutter
                contentWidth: availableWidth
                ColumnLayout {
                    width: settingsForm.availableWidth
                    Label { id: regionLabel; text: "AWS Region" }
                    TextField {
                        id: regionField
                        Layout.fillWidth: true
                        Accessible.name: regionLabel.text
                        text: "ap-northeast-1"
                        readOnly: !!plugin.pending
                        readonly property bool validRegion: /^[a-z]{2}(-[a-z0-9]+)+-[0-9]+$/.test(text.trim())
                        onTextEdited: plugin.message = ""
                    }
                    Label { id: keyLabel; text: "Amazon Location API key" }
                    TextField {
                        id: keyField
                        Layout.fillWidth: true
                        Layout.bottomMargin: 12
                        Accessible.name: keyLabel.text
                        echoMode: TextInput.Password
                        readOnly: !!plugin.pending
                        onTextEdited: plugin.message = ""
                    }
                    Label {
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        text: plugin.connectionHint || "These settings apply to place and route searches."
                        color: QfTheme.secondaryTextColor
                    }
                }
            }
        }
    }

    RoutePopup {
        id: features
        readonly property var visitsByFeature: {
            const visits = {}
            plugin.stops.forEach((stop, index) => {
                if (!stop.featureKey) return
                if (!visits[stop.featureKey]) visits[stop.featureKey] = []
                visits[stop.featureKey].push(index + 1)
            })
            return visits
        }
        function refreshList() {
            const layer = layers.currentValue
            if (!layer) {
                matches.clear()
                return
            }
            const term = featureFilter.text.trim()
            let filter = ""
            if (term) {
                // Quote the input as a QGIS string literal; strpos treats wildcards literally.
                const needle = "lower('" + term.replace(/\\/g, "\\\\").replace(/'/g, "''") + "')"
                const display = layer.displayExpression || "NULL"
                const name = "coalesce(nullif(to_string((" + display + ")), ''), to_string($id))"
                filter = "strpos(lower(" + name + "), " + needle + ") > 0"
                const idMatch = /^(?:fid\s+)?(-?\d+)$/i.exec(term)
                if (idMatch) filter += " OR $id = " + idMatch[1]
            }
            matches.setFeatures(layer, filter)
            featureList.positionViewAtBeginning()
        }
        onAboutToShow: refreshList()
        onAboutToHide: filterDelay.stop()
        onClosed: {
            featureFilter.clear()
            matches.clear()
        }
        Timer {
            id: filterDelay
            interval: 200
            onTriggered: features.refreshList()
        }
        ColumnLayout {
            anchors.fill: parent
            spacing: 0
            PanelHeader { title: "Select Features"; dismissText: "Done"; primaryDismiss: true; onDismissed: features.close() }
            RowLayout {
                Layout.fillWidth: true
                Layout.leftMargin: plugin.gutter
                Layout.rightMargin: plugin.gutter
                Layout.topMargin: plugin.gutter
                Label {
                    Layout.fillWidth: true
                    text: layers.currentText
                    textFormat: Text.PlainText
                    font: QfTheme.strongResultFont
                    wrapMode: Text.Wrap
                }
                Label {
                    text: plugin.stops.length + " / " + plugin.maxStops + " route stops"
                    font: QfTheme.tipFont
                    color: QfTheme.secondaryTextColor
                }
            }
            Label {
                Layout.fillWidth: true
                Layout.margins: plugin.gutter
                Layout.topMargin: 4
                Layout.bottomMargin: 4
                wrapMode: Text.Wrap
                text: plugin.atLimit ? "Stop limit reached (" + plugin.maxStops + ")."
                    : "Tap a feature to add a stop. Tap again to revisit."
            }
            RowLayout {
                Layout.fillWidth: true
                Layout.leftMargin: plugin.gutter
                Layout.rightMargin: plugin.gutter
                Layout.bottomMargin: 8
                TextField {
                    id: featureFilter
                    Layout.fillWidth: true
                    placeholderText: "Filter by name or ID"
                    Accessible.name: placeholderText
                    onTextChanged: if (features.visible) filterDelay.restart()
                    onAccepted: Qt.inputMethod.hide()
                }
                LocationButton {
                    text: "Clear"
                    Accessible.name: "Clear feature filter"
                    visible: featureFilter.text.length > 0
                    onClicked: featureFilter.clear()
                }
            }
            Label {
                Layout.leftMargin: plugin.gutter
                visible: matches.count === 0
                text: featureFilter.text.trim() ? "No matching features." : "There are no features in this layer."
            }
            ListView {
                id: featureList
                enabled: !filterDelay.running
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.leftMargin: plugin.gutter
                Layout.rightMargin: plugin.gutter
                Layout.bottomMargin: plugin.gutter
                spacing: 8
                clip: true
                model: matches
                delegate: ItemDelegate {
                    id: featureCard
                    readonly property string featureKey: model.currentLayer ? model.currentLayer.id + ":" + model.featureId : ""
                    readonly property var visits: features.visitsByFeature[featureKey] || []
                    readonly property bool added: visits.length > 0
                    readonly property string visitLabel: visits.length > 1 ? "Visits " + visits.join(", ")
                        : added ? "Visit " + visits[0] + " · " + plugin.stopRole(visits[0] - 1) : ""
                    width: ListView.view.width
                    padding: 12
                    implicitHeight: Math.max(plugin.touchHeight, implicitContentHeight + topPadding + bottomPadding)
                    enabled: plugin.canAddStop
                    opacity: !enabled && !added ? 0.6 : 1
                    text: model.featureName || ("FID " + model.featureId)
                    Accessible.name: added ? text + ", " + visitLabel : text
                    Accessible.description: added ? "Add another visit" : "Add to route"
                    background: Rectangle {
                        radius: 8
                        color: featureCard.down || featureCard.added ? plugin.colors.secondary.background : QfTheme.groupBoxSurfaceColor
                        border.color: featureCard.added || featureCard.visualFocus ? plugin.colors.selected.background : QfTheme.controlBorderColor
                        border.width: featureCard.visualFocus ? 2 : 1
                    }
                    contentItem: RowLayout {
                        spacing: 12
                        CircleBadge {
                            minimumSize: 28
                            text: featureCard.added ? "✓" : "+"
                            color: featureCard.added ? plugin.colors.selected.foreground : plugin.colors.secondary.foreground
                            fill: featureCard.added ? plugin.colors.selected.background : plugin.colors.secondary.background
                            Accessible.ignored: true
                        }
                        ColumnLayout {
                            Layout.fillWidth: true
                            spacing: 2
                            Label {
                                Layout.fillWidth: true
                                text: featureCard.text
                                textFormat: Text.PlainText
                                font: QfTheme.strongResultFont
                                color: QfTheme.mainTextColor
                                wrapMode: Text.Wrap
                            }
                            Label {
                                visible: featureCard.added
                                Layout.fillWidth: true
                                text: featureCard.visitLabel
                                color: plugin.colors.secondary.foreground
                                font: QfTheme.tipFont
                                wrapMode: Text.Wrap
                            }
                        }
                    }
                    onClicked: plugin.addStop(QfGeometryUtils.centroid(model.geometry), model.crs, text, featureKey)
                }
                ScrollBar.vertical: ScrollBar {}
            }
        }
    }
}
