import QtQuick
import QtQuick.Controls
import QtQuick.Controls.Material
import QtQuick.Layouts
import org.qgis
import org.qfield.core
import org.qfield.gui
import "Routes.js" as Routes

Item {
    id: plugin
    readonly property var window: iface.mainWindow()
    readonly property var canvas: iface.mapCanvas()
    readonly property var handler: iface.findItemByObjectName("pointHandler")
    readonly property var wgs84: QfCoordinateReferenceSystemUtils.wgs84Crs()
    property var stops: []
    property var pending: null
    property bool picking: false
    property string message: ""
    readonly property string handlerName: "AmazonLocationRoutes"

    readonly property color ink: "#232f3e"
    readonly property color orange: "#ff9900"
    readonly property color accent: QfTheme.darkTheme ? "#ff96a7" : "#b52745"
    readonly property int gutter: 16
    readonly property int touchHeight: 44
    readonly property bool atLimit: stops.length >= Routes.maxStops
    readonly property bool reorderable: stops.length > 1
    readonly property string statusText: message || searchHint
    readonly property string searchHint: {
        if (stops.length === 0) return "出発地と目的地を、訪問する順に追加してください。"
        if (stops.length === 1) return "目的地をあと1地点追加してください。"
        if (!regionField.validRegion) return "AWS リージョンを入力してください（例：ap-northeast-1）。"
        if (!keyField.text.trim()) return "Amazon Location API キーを入力してください。"
        return ""
    }

    Component.onCompleted: {
        iface.addItemToPluginsToolbar(toolButton)
        handler.registerHandler(handlerName, pickPoint, QfMapCanvasPointHandler.Priority.High)
    }
    Component.onDestruction: {
        if (handler) handler.deregisterHandler(handlerName)
        cancelRequest()
    }

    function pickPoint(screenPoint, device, interaction) {
        if (!picking || interaction !== "clicked") return false
        if (pending) return true
        const mapPoint = canvas.mapSettings.screenToCoordinate(screenPoint)
        addStop(mapPoint, canvas.mapSettings.destinationCrs, "地図上の地点")
        return true
    }

    function addStop(point, crs, label) {
        if (atLimit) {
            window.displayToast("指定できる地点は" + Routes.maxStops + "件までです。")
            return
        }
        const p = QfGeometryUtils.reprojectPointToWgs84(point, crs)
        if (!Routes.validPosition([p.x, p.y])) {
            window.displayToast("地点の座標を取得できませんでした。")
            return
        }
        stops = stops.concat([{ position: [p.x, p.y], label: label }])
        window.displayToast(stops.length + "番目に追加 · " + label)
    }

    function cancelRequest() {
        const request = pending
        pending = null
        timeout.stop()
        if (request) request.abort()
    }

    function moveStop(from, to) {
        if (pending || from < 0 || from >= stops.length || to < 0 || to >= stops.length || from === to) return
        const reordered = stops.slice()
        const stop = reordered.splice(from, 1)[0]
        reordered.splice(to, 0, stop)
        stops = reordered
    }

    onStopsChanged: {
        if (stopRows) stopRows.dragIndex = -1
        cancelRequest()
        route.geometryWrapper.clear()
        message = ""
    }

    onMessageChanged: {
        if (picking && message) window.displayToast(message)
    }

    function search() {
        const region = regionField.text.trim()
        const key = keyField.text.trim()
        if (pending || searchHint) return
        const body = Routes.requestBody(stops)
        const legCount = stops.length - 1
        const request = new XMLHttpRequest()
        pending = request
        message = ""
        request.onreadystatechange = function() {
            if (request.readyState !== XMLHttpRequest.DONE || pending !== request) return
            pending = null
            timeout.stop()
            if (request.status !== 200) {
                message = request.status === 0 ? "通信できません。接続を確認してください。"
                    : "検索できませんでした（HTTP " + request.status + "）。地点、リージョン、キーの権限を確認してください。"
                return
            }
            try {
                const data = JSON.parse(request.responseText)
                const geometry = QfGeometryUtils.createGeometryFromWkt(Routes.routeWkt(data, legCount))
                route.geometryWrapper.crs = wgs84
                route.geometryWrapper.qgsGeometry = geometry
                const projected = QfGeometryUtils.reprojectGeometry(geometry, wgs84, canvas.mapSettings.destinationCrs)
                iface.setMapExtent(QfGeometryUtils.boundingBox(projected))
                picking = false
                panel.close()
                window.displayToast(stops.length + "地点の経路を表示しました。")
            } catch (error) {
                message = error.message
            }
        }
        try {
            request.open("POST", "https://routes.geo." + region + ".amazonaws.com/v2/routes?key=" + encodeURIComponent(key))
            request.setRequestHeader("Content-Type", "application/json")
            timeout.start()
            request.send(JSON.stringify(body))
        } catch (error) {
            cancelRequest()
            message = "検索を開始できませんでした。"
        }
    }

    Timer {
        id: timeout
        interval: 45000
        onTriggered: {
            plugin.cancelRequest()
            plugin.message = "応答がありません。接続を確認して再検索してください。"
        }
    }

    Connections {
        target: iface
        function onLoadProjectTriggered() {
            plugin.picking = false
            features.close()
            panel.close()
            matches.clear()
            plugin.stops = []
        }
    }

    QfToolButton {
        id: toolButton
        round: true
        bgcolor: plugin.ink
        iconSource: Qt.resolvedUrl("icon.svg")
        iconColor: "transparent"
        bottomRightIndicatorText: plugin.picking ? String(plugin.stops.length) : ""
        Accessible.name: plugin.picking ? "地点の追加を終了して経路検索に戻る" : "Amazon Location 経路検索"
        onClicked: {
            plugin.picking = false
            panel.open()
        }
    }

    QfGeometryRenderer {
        id: route
        parent: plugin.canvas
        anchors.fill: parent
        mapSettings: plugin.canvas.mapSettings
        color: "#0079bd"
        lineWidth: 5
    }

    Item {
        parent: plugin.canvas
        anchors.fill: parent
        Repeater {
            model: plugin.stops
            delegate: Rectangle {
                required property var modelData
                required property int index
                CoordinateTransformer {
                    id: transformPoint
                    sourceCrs: plugin.wgs84
                    sourcePosition: QfGeometryUtils.point(modelData.position[0], modelData.position[1])
                    destinationCrs: plugin.canvas.mapSettings.destinationCrs
                    transformContext: qgisProject.transformContext
                }
                QfMapToScreen {
                    id: marker
                    mapSettings: plugin.canvas.mapSettings
                    mapPoint: transformPoint.projectedPosition
                }
                width: 24
                height: width
                radius: width / 2
                x: marker.screenPoint.x - width / 2
                y: marker.screenPoint.y - height / 2
                color: plugin.ink
                border.color: "white"
                Text { anchors.centerIn: parent; text: index + 1; color: "white" }
            }
        }
    }

    QfMultiFeatureListModel { id: matches }

    Button {
        parent: plugin.canvas.parent
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.bottom: parent.bottom
        anchors.bottomMargin: Math.max(plugin.window.sceneBottomMargin, plugin.canvas.bottomMargin) + plugin.gutter
        height: Math.max(implicitHeight, plugin.touchHeight)
        visible: plugin.picking && plugin.stops.length >= 2
        enabled: !plugin.pending
        text: plugin.pending ? "経路を検索中…" : plugin.searchHint ? "接続設定を入力" : "経路を検索"
        Accessible.description: plugin.statusText
        Material.background: enabled ? plugin.orange : QfTheme.controlBackgroundDisabledColor
        Material.foreground: plugin.ink
        onClicked: {
            if (plugin.searchHint) {
                plugin.picking = false
                panel.open()
            } else {
                plugin.search()
            }
        }
    }

    component RoutePopup: Popup {
        parent: plugin.window.contentItem
        anchors.centerIn: parent
        width: Math.min(440, parent.width - 16)
        height: Math.min(640, parent.height - 16)
        padding: 0
        modal: true
        focus: true
        Material.accent: plugin.accent
    }

    component PanelHeader: Rectangle {
        id: header
        property string title
        property string dismissText: "閉じる"
        signal dismissed()
        Layout.fillWidth: true
        implicitHeight: headerRow.implicitHeight + 16
        color: plugin.ink
        RowLayout {
            id: headerRow
            anchors.fill: parent
            anchors.leftMargin: plugin.gutter
            anchors.rightMargin: 8
            spacing: 10
            Image {
                source: Qt.resolvedUrl("icon.svg")
                Layout.preferredWidth: 32
                Layout.preferredHeight: 32
            }
            ColumnLayout {
                Layout.fillWidth: true
                spacing: 1
                Label { text: "Amazon Location Service"; color: "white"; font: QfTheme.tipFont }
                Label { text: header.title; color: "white"; font: QfTheme.strongTitleFont }
            }
            Button {
                flat: true
                text: header.dismissText
                Layout.minimumHeight: plugin.touchHeight
                Material.foreground: "white"
                onClicked: header.dismissed()
            }
        }
    }

    component SectionTitle: Label {
        Layout.fillWidth: true
        Layout.topMargin: 12
        font: QfTheme.strongResultFont
    }

    component MoveButton: ToolButton {
        required property int stopIndex
        required property int step
        readonly property int target: stopIndex + step
        text: step < 0 ? "↑" : "↓"
        visible: plugin.reorderable
        enabled: !plugin.pending && target >= 0 && target < plugin.stops.length
        Accessible.name: (stopIndex + 1) + "番目の地点を1つ" + (step < 0 ? "上" : "下") + "へ"
        onClicked: plugin.moveStop(stopIndex, target)
        Layout.preferredWidth: plugin.touchHeight
        Layout.minimumHeight: plugin.touchHeight
        ToolTip.visible: hovered || pressed
        ToolTip.text: Accessible.name
        ToolTip.delay: 600
    }

    component StopCard: Pane {
        id: card
        required property int index
        readonly property var stop: plugin.stops[index]
        readonly property string roleLabel: index === 0 ? "出発地" :
            index === plugin.stops.length - 1 ? "目的地" : "経由地"
        Layout.fillWidth: true
        Layout.minimumWidth: 0
        Layout.topMargin: 4
        readonly property bool held: stopRows.dragIndex === index
        z: held ? 1 : 0
        transform: Translate { y: stopRows.displacement(card.index) }
        padding: 10
        background: Rectangle {
            radius: 8
            color: QfTheme.groupBoxSurfaceColor
            border.color: card.held ? plugin.accent : QfTheme.controlBorderColor
            border.width: card.held ? 2 : 1
        }
        contentItem: RowLayout {
            spacing: 6
            MouseArea {
                Layout.preferredWidth: plugin.touchHeight
                Layout.preferredHeight: Math.max(plugin.touchHeight, gripLabels.implicitHeight)
                enabled: plugin.reorderable && !plugin.pending
                preventStealing: true
                cursorShape: pressed ? Qt.ClosedHandCursor : Qt.OpenHandCursor
                onPressed: mouse => {
                    form.contentItem.cancelFlick()
                    stopRows.pressY = mapToItem(form, mouse.x, mouse.y).y
                    stopRows.pointerY = stopRows.pressY
                    stopRows.startScroll = form.contentItem.contentY
                }
                onPositionChanged: mouse => {
                    if (!pressed) return
                    stopRows.pointerY = mapToItem(form, mouse.x, mouse.y).y
                    if (!card.held && Math.abs(stopRows.pointerY - stopRows.pressY) >= Qt.styleHints.startDragDistance)
                        stopRows.dragIndex = card.index
                }
                onReleased: mouse => {
                    if (!card.held) return
                    stopRows.pointerY = mapToItem(form, mouse.x, mouse.y).y
                    const target = stopRows.targetIndex
                    stopRows.dragIndex = -1
                    plugin.moveStop(card.index, target)
                }
                onCanceled: if (card.held) stopRows.dragIndex = -1
                ColumnLayout {
                    id: gripLabels
                    anchors.centerIn: parent
                    spacing: 2
                    Label {
                        text: card.index + 1
                        font: QfTheme.strongResultFont
                        color: "white"
                        horizontalAlignment: Text.AlignHCenter
                        verticalAlignment: Text.AlignVCenter
                        Layout.alignment: Qt.AlignHCenter
                        Layout.preferredWidth: Math.max(26, implicitWidth + 8, implicitHeight)
                        Layout.preferredHeight: Layout.preferredWidth
                        background: Rectangle { radius: height / 2; color: plugin.ink }
                    }
                    Label {
                        visible: plugin.reorderable
                        Layout.alignment: Qt.AlignHCenter
                        text: "⠿"
                        color: QfTheme.secondaryTextColor
                        Accessible.ignored: true
                    }
                }
            }
            ColumnLayout {
                Layout.fillWidth: true
                Layout.minimumWidth: 0
                spacing: 2
                Label { text: card.roleLabel; color: plugin.accent; font: QfTheme.tipFont }
                Label {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    text: card.stop ? card.stop.label : ""
                    textFormat: Text.PlainText
                    wrapMode: Text.Wrap
                    font: QfTheme.strongResultFont
                }
                Label {
                    Layout.fillWidth: true
                    Layout.minimumWidth: 0
                    text: card.stop ? card.stop.position[1].toFixed(5) + ", " + card.stop.position[0].toFixed(5) : ""
                    color: QfTheme.secondaryTextColor
                    wrapMode: Text.Wrap
                    font: QfTheme.tipFont
                }
            }
            MoveButton { stopIndex: card.index; step: -1 }
            MoveButton { stopIndex: card.index; step: 1 }
        }
    }

    RoutePopup {
        id: panel
        onAboutToHide: {
            stopRows.dragIndex = -1
            plugin.cancelRequest()
        }
        ColumnLayout {
            anchors.fill: parent
            spacing: 0
            PanelHeader { title: "経路検索"; onDismissed: panel.close() }
            ScrollView {
                id: form
                Layout.fillWidth: true
                Layout.fillHeight: true
                Layout.minimumHeight: 0
                clip: true
                contentWidth: availableWidth
                leftPadding: plugin.gutter
                rightPadding: plugin.gutter
                ColumnLayout {
                    width: form.availableWidth
                    spacing: 4
                    SectionTitle { text: "地点を追加" }
                    Button {
                        text: "地図をタップして地点を追加"
                        Layout.fillWidth: true
                        Layout.minimumHeight: plugin.touchHeight
                        enabled: !plugin.atLimit && !plugin.pending
                        onClicked: {
                            panel.close()
                            plugin.picking = true
                            plugin.window.displayToast("訪問順に地図をタップしてください。2地点以上で地図から経路を検索できます。")
                        }
                    }
                    Label { id: layerLabel; text: "地物を選ぶレイヤ" }
                    ComboBox {
                        id: layers
                        Layout.fillWidth: true
                        Accessible.name: layerLabel.text
                        model: QfMapLayerModel { project: qgisProject; filters: Qgis.LayerFilters.HasGeometry }
                        textRole: "Name"
                        valueRole: "LayerPointer"
                        displayText: count ? currentText : "対象のレイヤがありません"
                    }
                    Button {
                        text: "レイヤの地物を選択"
                        Layout.fillWidth: true
                        Layout.minimumHeight: plugin.touchHeight
                        enabled: !!layers.currentValue && !plugin.atLimit && !plugin.pending
                        onClicked: {
                            matches.setFeatures(layers.currentValue, "")
                            features.open()
                        }
                    }
                    SectionTitle { text: "接続設定" }
                    Label { id: regionLabel; text: "AWS リージョン" }
                    TextField {
                        id: regionField
                        Layout.fillWidth: true
                        Accessible.name: regionLabel.text
                        text: "ap-northeast-1"
                        readOnly: !!plugin.pending
                        readonly property bool validRegion: /^[a-z]{2}(-[a-z0-9]+)+-[0-9]+$/.test(text.trim())
                        onTextEdited: plugin.message = ""
                    }
                    Label { id: keyLabel; text: "Amazon Location API キー" }
                    TextField {
                        id: keyField
                        Layout.fillWidth: true
                        Layout.bottomMargin: 12
                        Accessible.name: keyLabel.text
                        echoMode: TextInput.Password
                        readOnly: !!plugin.pending
                        onTextEdited: plugin.message = ""
                    }
                    SectionTitle {
                        Layout.topMargin: 8
                        text: "訪問順（" + plugin.stops.length + " / " + Routes.maxStops + "）"
                    }
                    Label {
                        visible: plugin.reorderable
                        Layout.fillWidth: true
                        wrapMode: Text.Wrap
                        text: "左の番号を上下にドラッグして並べ替え"
                        color: QfTheme.secondaryTextColor
                    }
                    Repeater {
                        id: stopRows
                        property int dragIndex: -1
                        property real pressY
                        property real pointerY
                        property real startScroll
                        readonly property real offset: dragIndex < 0 ? 0 :
                            pointerY - pressY + form.contentItem.contentY - startScroll
                        readonly property int targetIndex: {
                            if (dragIndex < 0 || dragIndex >= count) return -1
                            const held = itemAt(dragIndex)
                            const center = held.y + held.height / 2 + offset
                            let target = dragIndex
                            while (target < count - 1 && center > midpoint(target + 1)) ++target
                            while (target > 0 && center < midpoint(target - 1)) --target
                            return target
                        }
                        function midpoint(index) {
                            const item = itemAt(index)
                            return item.y + item.height / 2
                        }
                        function displacement(index) {
                            if (dragIndex < 0 || dragIndex >= count) return 0
                            const held = itemAt(dragIndex)
                            if (index === dragIndex)
                                return Math.max(itemAt(0).y - held.y,
                                    Math.min(offset, itemAt(count - 1).y + itemAt(count - 1).height - held.y - held.height))
                            const step = held.height + held.Layout.topMargin + held.parent.spacing
                            if (index > dragIndex && index <= targetIndex) return -step
                            if (index < dragIndex && index >= targetIndex) return step
                            return 0
                        }
                        model: plugin.stops.length
                        delegate: StopCard {}
                    }
                    RowLayout {
                        visible: plugin.stops.length > 0
                        enabled: !plugin.pending
                        Button { flat: true; text: "末尾の地点を削除"; onClicked: plugin.stops = plugin.stops.slice(0, -1) }
                        Button { flat: true; text: "全消去"; onClicked: plugin.stops = [] }
                    }
                }
            }
            Rectangle { Layout.fillWidth: true; implicitHeight: 1; color: QfTheme.controlBorderColor }
            ColumnLayout {
                Layout.fillWidth: true
                Layout.margins: plugin.gutter
                spacing: 6
                ProgressBar {
                    Layout.fillWidth: true
                    visible: !!plugin.pending
                    indeterminate: visible
                    Accessible.name: "経路を検索中"
                }
                Label {
                    Layout.fillWidth: true
                    visible: text.length > 0
                    wrapMode: Text.Wrap
                    text: plugin.statusText
                    color: plugin.message ? plugin.accent : QfTheme.mainTextColor
                }
                Button {
                    Layout.fillWidth: true
                    Layout.minimumHeight: 48
                    enabled: !plugin.pending && !plugin.searchHint
                    Accessible.description: plugin.statusText
                    text: plugin.pending ? "経路を検索中…" : "指定順で最短経路を検索"
                    topInset: 0
                    bottomInset: 0
                    font: QfTheme.strongTitleFont
                    Material.background: enabled ? plugin.orange : QfTheme.controlBackgroundDisabledColor
                    Material.foreground: plugin.ink
                    onClicked: plugin.search()
                }
            }
        }
    }

    Timer {
        interval: 24
        repeat: true
        running: stopRows.dragIndex >= 0 && (stopRows.pointerY < plugin.touchHeight ||
            stopRows.pointerY > form.height - plugin.touchHeight)
        onTriggered: {
            const view = form.contentItem
            const first = stopRows.itemAt(0)
            const last = stopRows.itemAt(stopRows.count - 1)
            const edge = plugin.touchHeight
            const up = stopRows.pointerY < edge
            if (up && first.parent.mapToItem(form, 0, first.y).y >= 0) return
            if (!up && last.parent.mapToItem(form, 0, last.y + last.height).y <= form.height) return
            const step = edge / 5
            view.contentY = Math.max(view.originY, Math.min(view.contentY + (up ? -step : step),
                view.originY + view.contentHeight - view.height))
        }
    }

    RoutePopup {
        id: features
        onClosed: matches.clear()
        ColumnLayout {
            anchors.fill: parent
            spacing: 0
            PanelHeader { title: "地物を選択"; dismissText: "選択を終了"; onDismissed: features.close() }
            Label {
                Layout.fillWidth: true
                Layout.margins: plugin.gutter
                wrapMode: Text.Wrap
                text: plugin.atLimit ? "地点数が上限に達しました（" + Routes.maxStops + "地点）。"
                    : "訪問順に地物をタップ（現在 " + plugin.stops.length + " 地点）"
            }
            Label {
                Layout.leftMargin: plugin.gutter
                visible: matches.count === 0
                text: "このレイヤに地物はありません。"
            }
            ListView {
                Layout.fillWidth: true
                Layout.fillHeight: true
                clip: true
                model: matches
                delegate: ItemDelegate {
                    width: ListView.view.width
                    implicitHeight: Math.max(plugin.touchHeight, implicitContentHeight + topPadding + bottomPadding)
                    enabled: !plugin.atLimit
                    text: model.featureName || ("FID " + model.featureId)
                    onClicked: plugin.addStop(QfGeometryUtils.centroid(model.geometry), model.crs, text)
                }
                ScrollBar.vertical: ScrollBar {}
            }
        }
    }
}
